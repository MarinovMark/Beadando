
public class Program {
	static DbMethods dbm = new DbMethods();

	public static void main(String[] args) {
		dbm.Reg();
		String sqlp = "CREATE TABLE Categories (category_id, name)";
		dbm.CommandExec(sqlp);
		String sqlp2 = "INSERT INTO Categories Values('1', 'Action')";
		dbm.CommandExec(sqlp2);
		String sqlp3 = "INSERT INTO Categories Values('2', 'RPG')";
		dbm.CommandExec(sqlp3);
		String sqlp4 = "INSERT INTO Categories Values('3', 'Strategy')";
		dbm.CommandExec(sqlp4);
		String sqlp5 = "DELETE FROM Categories Where category_id=1";
		dbm.CommandExec(sqlp5);
		String sqlp6 = "DELETE FROM Categories Where category_id=2";
		dbm.CommandExec(sqlp6);
		String sqlp7 = "DELETE FROM Categories Where category_id=3";
		dbm.CommandExec(sqlp7);
		dbm.DisConnect(dbm.Connect());
		dbm.ReadAllData();

	}

}
