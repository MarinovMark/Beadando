
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DbMethods {

	public Connection Connect() {
		Connection conn = null;
		String url = "jdbc:sqlite:C:/sql3/jatekdb";
		try {
			conn = DriverManager.getConnection(url);
			SM("Sikeres kapcsolodds");
			return conn;
		} catch (Exception ex) {
			SM(ex.getMessage());
			return conn;
		}
	}

	public void DisConnect(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
				SM("Sikeres lekapcsolodds");
			} catch (Exception ex) {
				SM(ex.getMessage());
			}
		}
	}

	public void Reg() {
		try {
			Class.forName("org.sqlite.JDBC");
			SM("Sikeres driver regisztrálás");
		} catch (Exception ex) {
			SM(ex.getMessage());
		}
	}

	public void CommandExec(String command) {
		Connection conn = Connect();
		String sqlp = command;
		try {
			Statement s = conn.createStatement();
			s.execute(sqlp);
			SM("Command OK");
		} catch (SQLException e) {
			SM("command: " + sqlp);
			SM("CommandExec: " + e.getMessage());
		}
		DisConnect(conn);
	}

	public void ReadAllData() {
		String category_id = "", name = "", x = "\t";
		Connection conn = Connect();
		String sqlp = "SELECT category_id, name";
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while (rs.next()) {
				category_id = rs.getString("category_id");
				name = rs.getString("name");
				SM(category_id + x + name);
			}
			rs.close();

		} catch (SQLException e) {
			SM("ReadAllData: " + e.getMessage());
		}
		DisConnect(conn);
	}

	public void ReadAllData2() {
		String game_id = "", title = "", x = "\t";
		Connection conn = Connect();
		String sqlp = "SELECT game_id, title";
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while (rs.next()) {
				game_id = rs.getString("game_id");
				title = rs.getString("title");
				SM(game_id + x + title);
			}
			rs.close();

		} catch (SQLException e) {
			SM("ReadAllData: " + e.getMessage());
		}
		DisConnect(conn);
	}

	public void SM(String s) {
		System.out.println(s + "\n");
	}
}
